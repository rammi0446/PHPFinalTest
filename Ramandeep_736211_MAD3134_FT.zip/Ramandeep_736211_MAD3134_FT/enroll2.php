
<?php

// 1. connect to DATABASE

// 2. get all the rows back

// 3. show it in a table
  $dbhost = "localhost";		// address of your database
  $dbuser = "root";					// database username
  $dbpassword = "";					// database password: on MAMP, this is "root"
  $dbname = "school";							// @TODO: database name
  $conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);
  $query = 'SELECT * FROM instructors';
  $results = mysqli_query($conn, $query);

  session_start();

 $name = $_SESSION["name"];



?>



<html>
<head>
  <link rel="stylesheet" type="text/css" href="css/bulma.min.css">
  <style type="text/css">
    .container{
      margin-top:40px;
    }
    form {
      max-width:250px;
    }
    button {
      margin-top:10px;
    }
  </style>
</head>
<body>

<div class="container">
  <div class="content">

    <h1> Welcome, <?php echo "$name"; ?> </h1>

    <h1> Choose a Section </h1>

    <p>
      <?php
        while( $x = mysqli_fetch_assoc($results) ) {
          // clean up the user interface

          echo "Instructor Name:";
          echo $x["name"] ;
              echo "<br>";
            echo "Spots Remaining:";
            if( $x["seatsAvailable"] > 0)
            {
               echo $x["seatsAvailable"] ;
            echo "<br>";
          
            echo '<a href="enroll3.php?pos='. $x["id"] . '">Enroll</a>  ';
              echo "<br>";
            }
            else
            {
               echo $x["seatsAvailable"] ;
                 echo "<br>";
            }
         
         
        }
      ?>

    <a href="index.php>"> Go Back </a>

  </div>
</div>

</body>
</html>
