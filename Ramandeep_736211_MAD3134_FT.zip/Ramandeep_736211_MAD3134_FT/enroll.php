<?php
echo "hello";
// 1. connect to DATABASE

// 2. get all the rows back
if ($_SERVER["REQUEST_METHOD"] == "POST"){
// 3. show it in a table

$key =   $_POST["key"];

  $dbhost = "localhost";		// address of your database
  $dbuser = "root";					// database username
  $dbpassword = "";					// database password: on MAMP, this is "root"
  $dbname = "school";				// @TODO: database name
  $conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);
  $query = "SELECT * FROM students where akey='$key'";
  $results = mysqli_query($conn, $query);
  $y = mysqli_num_rows($results);

  if(isset($y)) {
   if ($y == 0)
   {
    echo "<span style='color:red'> Error - sorry you entered wrong key </span><br>";
   }
   else {

        header("Location: enroll2.php");

   }
  }

}

?>





<html>
<head>
  <link rel="stylesheet" type="text/css" href="css/bulma.min.css">
  <style type="text/css">
    .container{
      margin-top:40px;
    }
    form {
      max-width:250px;
    }
    button {
      margin-top:10px;
    }
  </style>
</head>
<body>

<div class="container">
  <div class="content">

    <h1> Enter Your Access Key </h1>

    <form action="enroll.php" method="POST">
      Access Key:  <input class="input" type="text" name="key"> <br>
      <button type="submit" class="button is-outlined is-link"> Next </button>
    </form>

    <a href="index.html"> Go Back </a>

  </div>
</div>

</body>
</html>
