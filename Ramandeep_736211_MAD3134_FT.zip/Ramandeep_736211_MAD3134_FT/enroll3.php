
<?php

if ($_SERVER["REQUEST_METHOD"] == "GET"){
// 3. show it in a table

$instid =   $_GET["pos"];
  $dbhost = "localhost";		// address of your database
  $dbuser = "root";					// database username
  $dbpassword = "";					// database password: on MAMP, this is "root"
  $dbname = "school";							// @TODO: database name
  $conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);
$query = "SELECT * FROM instructors where id = '$instid'";
  $results = mysqli_query($conn, $query);
  $y = mysqli_num_rows($results);


    while( $x = mysqli_fetch_assoc($results) ) {
      
      $str = $x["seatsAvailable"]-1;
      $query1 =  "UPDATE instructors set seatsAvailable='$str' where id='$instid'";
      $results1 = mysqli_query($conn, $query1);
    }

}
?>



<html>
<head>
  <link rel="stylesheet" type="text/css" href="css/bulma.min.css">
  <style type="text/css">
    .container{
      margin-top:40px;
    }
    form {
      max-width:250px;
    }
    button {
      margin-top:10px;
    }
  </style>
</head>
<body>

<div class="container">
  <div class="content">
<?php
session_start();
$name = $_SESSION["name"];
?>
    <h1> Welcome, <?php echo "$name"; ?></h1>

    <h1> Enrollment Confirmation </h1>

    <p>
      Success! You are enrolled!
    </p>

    <a href="index.php"> Go Back </a>

  </div>
</div>

</body>
</html>
