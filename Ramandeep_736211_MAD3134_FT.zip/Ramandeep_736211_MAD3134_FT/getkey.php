<?php

// 1. connect to DATABASE

// 2. get all the rows back
if ($_SERVER["REQUEST_METHOD"] == "POST"){
// 3. show it in a table
$name =   $_POST["name"];
$stuid =   $_POST["id"];

  $dbhost = "localhost";		// address of your database
  $dbuser = "root";					// database username
  $dbpassword = "";					// database password: on MAMP, this is "root"
  $dbname = "school";							// @TODO: database name
  $conn = mysqli_connect($dbhost,$dbuser,$dbpassword,$dbname);
  $query = "SELECT * FROM students where studentid='$stuid'";
  $results = mysqli_query($conn, $query);
  $y = mysqli_num_rows($results);
  if(isset($y)) {
   if ($y == 0)
   {
    echo "<span style='color:red'> Error - sorry you are not in database please contact student service for assistance </span><br>";
   }
   else {
    
      $str = "Hello";
      $str = md5($str);
      echo "please note down your access key";
      echo "<br>";
      echo $str;
      $query1 = "UPDATE students set akey='$str' where studentid='$stuid'";
      $results = mysqli_query($conn, $query1);

      session_start();
      $_SESSION["name"] = "$name";

   }
  }

}

?>







<html>
<head>
  <link rel="stylesheet" type="text/css" href="css/bulma.min.css">
  <style type="text/css">
    .container{
      margin-top:40px;
    }
    form {
      max-width:250px;
    }
    button {
      margin-top:10px;
    }
  </style>
</head>
<body>

<div class="container">
  <div class="content">

    <h1> Register for an Access Key </h1>

    <form action="getkey.php" method="POST">
      Name:  <input class="input" type="text" name="name"> <br>
      ID:    <input class="input" type="text" name="id"> <br>

      <button type="submit" class="button is-outlined is-link"> Generate Key </button>
      <button class="button is-outlined is-link"><a href="enroll.php">Enroll</a></button>

    </form>

    <a href="index.php"> Go Back </a>

  </div>
</div>

</body>
</html>
